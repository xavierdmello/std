# std
Useful for Python programmers transferring over from C++.

# Example
```
from std import *
#include <iostream>

int;main(); {
    std:cout << "Hello World!"
}
```

# Usage
1. download std.py
2. import std with `from std import *`
