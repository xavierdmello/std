class std:
    def __lshift__(self, a):
        print(a)

def main():pass
cout = std()
