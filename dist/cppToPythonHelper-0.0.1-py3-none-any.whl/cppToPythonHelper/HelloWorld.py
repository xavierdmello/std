from std import *
#include <iostream>

int;main(); {
    std:cout << "Hello World!"
}
